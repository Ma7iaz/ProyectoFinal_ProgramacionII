/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mangopaint;

/** JF : Principal JFrame (window generator)
 *  lin: Lienzo para dibujar (canvas)
 *  pan: Panel de herramientas principal (tool bar)
 * 
 * @author eparr
 */
public class MainClass {

    
    public static void main(String[] args) {
        
        JF jf = new JF();
        jf.pack();         // what ??
        
    }
    
}
