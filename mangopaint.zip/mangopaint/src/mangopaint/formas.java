/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mangopaint;

import java.awt.Graphics;
import java.util.ArrayList;

/**
 *
 * clase formas para dibujar formas
 */




public class formas {
    private lin VIP;
ArrayList< Integer > px;    
ArrayList< Integer > py;    
ArrayList< Integer > fx;    
ArrayList< Integer > fy;    
ArrayList< Integer > type;
int counter;
boolean mostrar;

public formas(lin a){
    
    VIP = a;
    px = new ArrayList<>();
    py = new ArrayList<>();
    fx = new ArrayList<>();
    fy = new ArrayList<>();
    type = new ArrayList<>();
    counter = -1;
    mostrar = false;
    
}    
    
    /**
     * unica funcion para setear las pocisiones de las figuras por clicks
     * 
     * @param ppx  X
     * @param ppy   Y
     * @param forma  1 cuadrado 2 rectangulo 3 circulo 4 lleno circulo0
     */
public void PrimerPunto(int ppx , int ppy , int forma){
    if(mostrar){UltimoPunto(ppx,ppy); mostrar = false; return;}
    px.add(ppx);
    py.add(ppy);
    fx.add(ppx + 5);
    fy.add(ppy + 5);
    
   
    type.add(forma);
    
    counter ++;
    
    mostrar = true;
    System.out.println("inic");
    
}    

/**
 * mueve los valores del punto final segun mouse moved para ver una vista previa
 * @param ax
 * @param ay 
 */
public void VistaPrevia(int ax , int ay){
    
    if(mostrar){
    fx.set(counter, ax);
    fy.set(counter, ay);
    
    
    }
}

    /**
     * 
     * Funcion para set el ultimo punto. se usa en PrimerPunto
     * 
     * @param ffx
     * @param ffy 
     */
public void UltimoPunto(int ffx , int ffy){
    
     fx.set(counter, ffx);
    fy.set(counter, ffy);
    
    
    
    
    
    mostrar = false;
    System.out.println("ULTIMPO");
}


/**
 * 
 * Cumple el rol de paint
 * @param g 
 */
public void dibujarfiguras(Graphics g){
    
    
    for(int i = 0; i<=counter ; i++){
        
        if(type.get(i) == 1 ){
            
            g.drawRect(px.get(i), py.get(i), fx.get(i) - px.get(i) , fx.get(i) - px.get(i) );
            
          
            
            
        }
        
         if(type.get(i) == 2){
            
             g.drawRect(px.get(i), py.get(i), fx.get(i) - px.get(i) , fy.get(i) - py.get(i) );
             
            
        }
        
         if(type.get(i) == 3){
            
         
            g.drawOval(px.get(i), py.get(i), fx.get(i) - px.get(i) , fy.get(i) - py.get(i) );
             
        }
        
         if(type.get(i) == 4){
            
             
            g.fillOval(px.get(i), py.get(i), fx.get(i) - px.get(i) , fy.get(i) - py.get(i) );
             
             
             
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
}
    
    
    
    
    










    
    
    
    
    
    
    
    
}









